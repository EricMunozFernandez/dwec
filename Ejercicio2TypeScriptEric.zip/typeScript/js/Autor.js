var Autor = /** @class */ (function () {
    function Autor(dni, nombreApellidos) {
        this.dni = dni;
        this.nombreApellidos = nombreApellidos;
    }
    return Autor;
}());
